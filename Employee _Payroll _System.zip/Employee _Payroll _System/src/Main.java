import java.util.ArrayList;

// abstract class create 
abstract class Employee{
	
	
	// Access modifier private used
	private int id;
	private String name;
	
	
	// constructor
	
	public Employee(int id, String name) {
	    this.id = id;
	    this.name = name;
	}

	
	// we can used getter and setter method get the method
	
	public int getId() {
		return id;
	}
	
	public String name() {
		return name;
		
	}
	
	
	// we can create the abstract method
public	abstract  double calculateSalary() ;
// polymoriphm @override(name same but different method)


@Override
public String toString() {
	return "Employee[name ="+name+",id="+id+",salary="+calculateSalary()+"]";
	
}

}

class  FullTimeSalary extends Employee{
	private double monthlysalary;
	
	
	public FullTimeSalary(String name,int id, double montlysalary) {
		super(id,name);
		this.monthlysalary=monthlysalary;
		
		
	}
	
	@Override
	public double calculateSalary() {
		return monthlysalary;
	}
}

class PartTimeSalary extends Employee{
	
	private int hoursworked;
	private double hourlyRate;
	
	
	public PartTimeSalary(String name,int id,int hoursworked,double hourlyRate  ) {
		super(id,name);
		this.hoursworked=hoursworked;
		this.hourlyRate=hourlyRate;
	}
	
	@Override
	public double calculateSalary() {
		return hoursworked*hourlyRate;
	}
}

class PayrollSystem{
	
	private static ArrayList <Employee> employeelist;
	
	public PayrollSystem() {
		employeelist=new ArrayList<>();
		
	}
	
	public  void addemployee(Employee employee) {
		
		try {
			employeelist.add(employee);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public  void removeemployee(int id) {
		
		Employee employeeToremove =null;
		
		for(Employee employee: employeelist) {
			if(employee.getId()==id) {
				
				employeeToremove=employee;
				break;
				
			}
		}
		
		if(employeeToremove!=null) {
			employeelist.remove(employeeToremove);
		}
		
	}
	
	public  void displayEmployee() {
		
		for(Employee employee:employeelist) {
			System.out.println(employee);
		}
		
	}
}


public class Main {

    public static void main(String[] args) {
        PayrollSystem payrollSystem = new PayrollSystem();
        FullTimeSalary emp1 = new FullTimeSalary("rashi", 1, 70000.00);
        PartTimeSalary emp2 = new PartTimeSalary("Aditi", 2, 40, 100);

        payrollSystem.addemployee(emp1);
        payrollSystem.addemployee(emp2);

        System.out.println("Initializing the Employee");

        payrollSystem.displayEmployee();

        System.out.println("Remove the Employee list");

        payrollSystem.removeemployee(2);
        payrollSystem.displayEmployee();

        System.out.println("Remaining Employee Detail");
        payrollSystem.displayEmployee();
    }
}

